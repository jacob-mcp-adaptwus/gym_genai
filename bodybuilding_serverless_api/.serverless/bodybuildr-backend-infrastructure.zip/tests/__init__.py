"""
Unit tests for the bodybuilding API handlers
""" 