# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


from .raw_message_start_event import RawMessageStartEvent

__all__ = ["MessageStartEvent"]

MessageStartEvent = RawMessageStartEvent
"""The RawMessageStartEvent type should be used instead"""
